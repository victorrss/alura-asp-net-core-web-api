﻿using Microsoft.AspNetCore.Identity;

namespace Alura.ListaLeitura.Seguranca
{
    public class Usuario : IdentityUser
    {
    }
}
